package com.hryniuk.dev.ui.myticket;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.hryniuk.dev.R;

public class MyticketFragment extends Fragment {

    public TextView validToTEXT, zoneTEXT, timerTEXT, adultTEXT, kron1TEXT, kron2TEXT, dataTEXT, ticketTEXT;
    public ImageView pictureTEXT;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_myticket, container, false);

        validToTEXT = root.findViewById(R.id.validToTEXT);
        zoneTEXT = root.findViewById(R.id.zoneTEXT);
        timerTEXT = root.findViewById(R.id.timerTEXT);
        adultTEXT = root.findViewById(R.id.adultTEXT);
        kron1TEXT = root.findViewById(R.id.kron1TEXT);
        kron2TEXT = root.findViewById(R.id.kron2TEXT);
        dataTEXT = root.findViewById(R.id.dataTEXT);
        ticketTEXT = root.findViewById(R.id.ticketTEXT);
        pictureTEXT = root.findViewById(R.id.pictureTEXT);



       if (getArguments() != null) {
           // adultTEXT.setText(getArguments().getString("adultTEXT"));
            Toast.makeText(getContext(), getArguments().getString("adultTEXT"), Toast.LENGTH_SHORT).show();
        }
        else {
            //adultTEXT.setText ("1 Adult");
            Toast.makeText(getContext(), "1 Adult", Toast.LENGTH_SHORT).show();

        }



        return root;
    }

    @Override
    public void onStart() {




        super.onStart();
    }
}
